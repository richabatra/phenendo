## 
## Check that multistage samples still work
##
library(survey)
example(mu284)

