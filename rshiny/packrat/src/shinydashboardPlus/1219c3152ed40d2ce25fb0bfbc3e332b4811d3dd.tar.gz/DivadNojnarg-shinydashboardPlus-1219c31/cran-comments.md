## Test environments
* local OS X install, R 3.4.4
* ubuntu 14.04 (on travis-ci), R 3.5.0 (2017-01-27)
* Windows (via devtools::build_win(), R-devel)

[![Build Status](https://travis-ci.org/DivadNojnarg/shinydashboardPlus.svg?branch=master)](https://travis-ci.org/DivadNojnarg/shinydashboardPlus)

## R CMD check results
There were no ERRORs or WARNINGs or NOTEs


## Reverse dependencies:
using `devtools::revdep()` and R CMD check shinyWidgets

## Re-submission notes 
The help section is < 5MB