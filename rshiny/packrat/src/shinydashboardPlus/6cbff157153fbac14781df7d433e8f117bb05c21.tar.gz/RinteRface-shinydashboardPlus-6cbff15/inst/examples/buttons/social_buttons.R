social_buttons <- 'box(
  width = NULL,
  title = "Social Buttons",
  status = NULL,
  socialButton(
    url = "http://dropbox.com",
    type = "dropbox"
  ),
  socialButton(
    url = "http://github.com",
    type = "github"
  )
)'